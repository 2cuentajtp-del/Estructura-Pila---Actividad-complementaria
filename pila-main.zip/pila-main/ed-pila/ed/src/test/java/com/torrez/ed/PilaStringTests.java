package com.torrez.ed;

import org.junit.jupiter.api.Test;

import java.util.EmptyStackException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PilaStringTests {

    @Test
    void pilaVaciaAlInicio() {
        PilaString pila = new PilaString();
        assertEquals(0, pila.size());
        assertTrue(pila.isEmpty());
    }

    @Test
    void agregarAumentaSize() {
        PilaString pila = new PilaString();
        pila.agregar("A");
        pila.agregar("B");
        assertEquals(2, pila.size());
    }

    @Test
    void quitarDevuelveElUltimoAgregado() {
        PilaString pila = new PilaString();
        pila.agregar("A");
        pila.agregar("B");
        pila.agregar("C");

        assertEquals("C", pila.quitar());
        assertEquals(2, pila.size());
    }

    @Test
    void quitarEnPilaVaciaLanzaExcepcion() {
        PilaString pila = new PilaString();
        assertThrows(EmptyStackException.class, pila::quitar);
    }

    @Test
    void mostrarDevuelveDeCimaABase() {
        PilaString pila = new PilaString();
        pila.agregar("A");
        pila.agregar("B");
        pila.agregar("C");

        List<String> resultado = pila.mostrar();
        assertEquals(List.of("C", "B", "A"), resultado);
    }
}
