package com.torrez.ed;

import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;

public class PilaString {

    private final List<String> elementos = new ArrayList<>();


    public int size() {
        return elementos.size();
    }


    public void agregar(String valor) {
        elementos.add(valor);
    }

    public String quitar() {
        if (elementos.isEmpty()) {
            throw new EmptyStackException();
        }
        return elementos.remove(elementos.size() - 1);
    }


    public List<String> mostrar() {
        List<String> copia = new ArrayList<>(elementos);
        java.util.Collections.reverse(copia);
        return copia;
    }

    public boolean isEmpty() {
        return elementos.isEmpty();
    }
}
