package com.torrez.ed;

import org.springframework.web.bind.annotation.*;

import java.util.EmptyStackException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/pila")
public class PilaController {

    private final PilaString pila = new PilaString();

    @GetMapping("/size")
    public Map<String, Integer> size() {
        return Map.of("size", pila.size());
    }

    @PostMapping("/agregar")
    public Map<String, Object> agregar(@RequestParam String valor) {
        pila.agregar(valor);
        return Map.of("agregado", valor, "size", pila.size());
    }

    @DeleteMapping("/quitar")
    public Map<String, Object> quitar() {
        try {
            String valor = pila.quitar();
            return Map.of("quitado", valor, "size", pila.size());
        } catch (EmptyStackException e) {
            return Map.of("error", "La pila está vacía");
        }
    }

    @GetMapping
    public List<String> mostrar() {
        return pila.mostrar();
    }
}
